//
//  UserDefine.h
//  图灵机器人
//
//  Created by XF on 16/8/10.
//  Copyright © 2016年 xf. All rights reserved.
//

#ifndef UserDefine_h
#define UserDefine_h

#define RobotAPIKey @"43805a7c788a4d75a2b3c004278ddba9"
#define BaiduAPIKey @"ihLh2UZR7kBi4RyFVeauMMkG"
#define BaiduSecretKey @"f0ccd0841bc49a6860e3a9f63b43ecf6"

#endif /* UserDefine_h */
