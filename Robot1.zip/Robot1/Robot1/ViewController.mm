//
//  ViewController.m
//  Robot1
//
//  Created by XF on 16/8/11.
//  Copyright © 2016年 xf. All rights reserved.
//

#import "ViewController.h"
#import "TRRVoiceRecognitionManager.h"
#import "UserDefine.h"
#import "GlobalNetWorking.h"
#import "TRRTuringAPIConfig.h"
#import "TRRTuringRequestManager.h"
#import "TRRSpeechSythesizer.h"
@interface ViewController ()<TRRVoiceRecognitionManagerDelegate>

@property (strong, nonatomic) TRRVoiceRecognitionManager *sharedInstance;

@property (nonatomic, strong) TRRSpeechSythesizer *sythesizer;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUILayout];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    _sharedInstance = [TRRVoiceRecognitionManager sharedInstance];
    [_sharedInstance setApiKey:BaiduAPIKey secretKey:BaiduSecretKey];
    _sharedInstance.delegate = self;
    NSArray *array = @[@(20000)];
    _sharedInstance.recognitionPropertyList = array;
    self.sythesizer = [[TRRSpeechSythesizer alloc] initWithAPIKey:BaiduAPIKey secretKey:BaiduSecretKey];
}
#pragma mark - **************** 进行UI布局
-(void)setUILayout{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0, 120, 40);
    button.center = self.view.center;
    [button setTitle:@"点击说话" forState:UIControlStateNormal];
    [button setTitle:@"正在说话" forState:UIControlStateHighlighted];
    [button setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor brownColor] forState:UIControlStateHighlighted];
    UILongPressGestureRecognizer *longpress = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longTouchWith:)];
    [button addGestureRecognizer:longpress];
    button.layer.cornerRadius = 3;
    button.layer.borderWidth = 1;
    button.layer.borderColor = [UIColor blueColor].CGColor;
    [self.view addSubview:button];
}
#pragma mark - **************** 长按手势
-(void)longTouchWith:(UILongPressGestureRecognizer *)longPress{
    if (longPress.state == UIGestureRecognizerStateBegan) {
        [_sharedInstance startVoiceRecognition];
    }else if(longPress.state == UIGestureRecognizerStateEnded){
        [_sharedInstance stopRecognize];
    }
    
}
#pragma mark - **************** 语音识别结果
- (void)onRecognitionResult:(NSString *)result {
    NSLog(@"result = %@", result);
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setObject:RobotAPIKey forKey:@"key"];
    [dic setObject:result forKey:@"info"];
    [dic setObject:@"123456" forKey:@"userid"];
    [self netWorkingWith:dic];
}
#pragma mark ---- 语音识别错误
- (void)onRecognitionError:(NSString *)errStr {
    NSLog(@"Error = %@", errStr);
}

- (void)onStartRecognize {
    NSLog(@"开始说话");
}

- (void)onSpeechStart {
    NSLog(@"检测到已说话");
}

- (void)onSpeechEnd {
    NSLog(@"检测到已停止说话");
    
}
#pragma mark - **************** 网络请求
-(void)netWorkingWith:(NSDictionary *)dic{
    [GlobalNetWorking networkWithUrl:@"http://www.tuling123.com/openapi/api" andParametersDic:dic andSuccess:^(id rootObject, id datasObject, bool isSuccess) {
        //这里获取到机器人反馈的回答
        NSString *text = rootObject[@"text"];
        NSLog(@"%@",text);
        //进行语音合成
        [self.sythesizer start: text];
    } andFailure:^(NSError *error) {
        [self.sythesizer start:@"网络请求出错！"];
    }];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
