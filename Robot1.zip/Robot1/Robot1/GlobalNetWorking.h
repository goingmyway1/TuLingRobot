//
//  GlobalNetWorking.h
//  tongji
//
//  Created by XF on 16/7/18.
//  Copyright © 2016年 xf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"

@interface GlobalNetWorking : NSObject
//判断是否有网络
+(BOOL)isHasNetwork;

//普通post网络请求
+(void)networkWithUrl:(NSString *)url andParametersDic:(NSDictionary *)parameters andSuccess:(void (^)(id rootObject, id datasObject, bool isSuccess))success andFailure:(void (^)(NSError *error))failure;

@end
