//
//  GlobalNetWorking.m
//  tongji
//
//  Created by XF on 16/7/18.
//  Copyright © 2016年 xf. All rights reserved.
//

#import "GlobalNetWorking.h"

@implementation GlobalNetWorking


+(AFNetworkReachabilityStatus)currentNetworkStatus{
    
    static AFNetworkReachabilityStatus currentNetworkStatus = AFNetworkReachabilityStatusUnknown;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
            currentNetworkStatus = status;
        }];
    });
    return currentNetworkStatus;
}
+(BOOL)isHasNetwork{
    BOOL flag = YES;
    AFNetworkReachabilityStatus statue = [self currentNetworkStatus];
    if (statue == AFNetworkReachabilityStatusUnknown || statue == AFNetworkReachabilityStatusNotReachable) {
        flag = NO;
    }
    return flag;
}

+(void)networkWithUrl:(NSString *)url andParametersDic:(NSDictionary *)parameters andSuccess:(void (^)(id, id, bool))success andFailure:(void (^)(NSError *))failure{
    AFHTTPSessionManager *sessionManager = [AFHTTPSessionManager manager];
    sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [sessionManager POST:url parameters:parameters success:^(NSURLSessionDataTask *task, id responseObject) {
         NSDictionary *rootDic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        if (rootDic.count != 0) {
            success(rootDic,rootDic,YES);
        }
        NSLog(@"%@",rootDic);
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"%@",[error description]);
    }];
}


@end
